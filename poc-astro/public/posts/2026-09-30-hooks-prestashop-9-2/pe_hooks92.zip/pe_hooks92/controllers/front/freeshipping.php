<?php
declare(strict_types=1);

/**
 * Returns the free shipping block alone, for the AJAX refresh of the cart page.
 */
class Pe_Hooks92FreeshippingModuleFrontController extends ModuleFrontController
{
    public function init(): void
    {
        $this->ajax = true;
        parent::init();
    }

    public function displayAjax(): void
    {
        /** @var Pe_Hooks92 $module */
        $module = $this->module;

        header('Cache-Control: no-store');
        $this->ajaxRender($module->renderFreeShippingProgress());
    }
}
