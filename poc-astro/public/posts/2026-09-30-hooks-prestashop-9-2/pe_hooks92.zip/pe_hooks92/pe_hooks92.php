<?php
/**
 * Demo module for the new PrestaShop 9.2 hooks.
 *
 * @author    PrestaEdit
 * @license   AFL-3.0
 */
declare(strict_types=1);

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/vendor/autoload.php';

use PrestaEdit\Hooks92\Checkout\B2bCheckoutProvider;
use PrestaEdit\Hooks92\Checkout\CheckoutPurchaseOrderStep;
use PrestaShop\PrestaShop\Adapter\Order\Checkout\CheckoutProcessProviderInterface;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Validator\Constraints as Assert;

class Pe_Hooks92 extends Module
{
    public const CONFIG_B2B_GROUP = 'PE_HOOKS92_B2B_GROUP';
    public const CONFIG_WARRANTY_MONTHS = 'PE_HOOKS92_WARRANTY_MONTHS';
    public const CONFIG_RETURN_EMAIL = 'PE_HOOKS92_RETURN_EMAIL';
    public const NOT_FOUND_TABLE = 'pe_hooks92_not_found';

    private const HOOKS = [
        'actionCheckoutBuildProcess',
        'actionValidateOrder',
        'actionFrontControllerSetMedia',
        'displayCartBelowSummary',
        'displayOrderDetailProductLine',
        'displaySubcategories',
        'actionNotFound',
        'actionOrderReturnForm',
    ];

    /** @var array<int, Order|null> */
    private array $orderCache = [];

    public function __construct()
    {
        $this->name = 'pe_hooks92';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'PrestaEdit';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '9.2.0', 'max' => _PS_VERSION_];

        parent::__construct();

        $this->displayName = $this->trans('New hooks of PrestaShop 9.2', [], 'Modules.Pehooks92.Admin');
        $this->description = $this->trans('Demo of the front office hooks added in PrestaShop 9.2.', [], 'Modules.Pehooks92.Admin');
    }

    public function isUsingNewTranslationSystem(): bool
    {
        return true;
    }

    public function install(): bool
    {
        return parent::install()
            && $this->installDatabase()
            && Configuration::updateValue(self::CONFIG_B2B_GROUP, 0)
            && Configuration::updateValue(self::CONFIG_WARRANTY_MONTHS, 24)
            && $this->registerHook(self::HOOKS);
    }

    public function uninstall(): bool
    {
        Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . self::NOT_FOUND_TABLE . '`');

        return Configuration::deleteByName(self::CONFIG_B2B_GROUP)
            && Configuration::deleteByName(self::CONFIG_WARRANTY_MONTHS)
            && Configuration::deleteByName(self::CONFIG_RETURN_EMAIL)
            && parent::uninstall();
    }

    private function installDatabase(): bool
    {
        return Db::getInstance()->execute(
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . self::NOT_FOUND_TABLE . '` (
                `id_not_found` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_shop` INT UNSIGNED NOT NULL,
                `request_uri` VARCHAR(255) NOT NULL,
                `redirect_to` VARCHAR(255) DEFAULT NULL,
                `hits` INT UNSIGNED NOT NULL DEFAULT 0,
                `date_last_hit` DATETIME NOT NULL,
                PRIMARY KEY (`id_not_found`),
                UNIQUE KEY `shop_uri` (`id_shop`, `request_uri`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4'
        );
    }

    /*
     * 1. actionCheckoutBuildProcess
     */
    public function hookActionCheckoutBuildProcess(array $params): CheckoutProcessProviderInterface
    {
        return new B2bCheckoutProvider($this->context);
    }

    public function hookActionValidateOrder(array $params): void
    {
        /** @var Cart $cart */
        $cart = $params['cart'];
        /** @var Order $order */
        $order = $params['order'];

        $purchaseOrder = CheckoutPurchaseOrderStep::getPurchaseOrderFromCart((int) $cart->id);
        if ($purchaseOrder === '') {
            return;
        }

        $order->note = trim($order->note . "\n" . sprintf('Purchase order: %s', $purchaseOrder));
        $order->update();
    }

    /*
     * 2. displayCartBelowSummary
     */
    public function hookActionFrontControllerSetMedia(): void
    {
        if ($this->context->controller->php_self !== 'cart') {
            return;
        }

        $this->context->controller->registerJavascript(
            'pe-hooks92-free-shipping',
            'modules/' . $this->name . '/views/js/free-shipping.js',
            ['position' => 'bottom', 'priority' => 200]
        );
    }

    public function hookDisplayCartBelowSummary(array $params): string
    {
        // The container stays in the page even when empty, so the JS refresh always has a target.
        return '<div class="js-pe-free-shipping" data-refresh-url="'
            . htmlspecialchars($this->context->link->getModuleLink($this->name, 'freeshipping'), ENT_QUOTES)
            . '">' . $this->renderFreeShippingProgress() . '</div>';
    }

    public function renderFreeShippingProgress(): string
    {
        $cart = $this->context->cart;
        if (!Validate::isLoadedObject($cart) || $cart->isVirtualCart()) {
            return '';
        }

        // Same threshold as Cart::getPackageShippingCost(): configuration value converted
        // to the cart currency, then open to modules through actionOverrideShippingFreePrice.
        $threshold = (float) Configuration::get('PS_SHIPPING_FREE_PRICE');
        if ($threshold > 0) {
            $threshold = (float) Tools::convertPrice($threshold, Currency::getCurrencyInstance((int) $cart->id_currency));
        }
        Hook::exec('actionOverrideShippingFreePrice', [
            'shippingFreePrice' => &$threshold,
            'id_zone' => $this->getCartZoneId($cart),
            'id_currency' => (int) $cart->id_currency,
        ]);

        if ($threshold <= 0) {
            return '';
        }

        $total = (float) $cart->getOrderTotal(true, Cart::BOTH_WITHOUT_SHIPPING, null, null, false);
        $remaining = max(0.0, $threshold - $total);
        $locale = $this->context->getCurrentLocale();
        $isoCode = Currency::getIsoCodeById((int) $cart->id_currency);

        $this->context->smarty->assign([
            'free_shipping' => [
                'reached' => $remaining <= 0,
                'remaining' => $locale->formatPrice($remaining, $isoCode),
                'percent' => (int) min(100, floor($total / $threshold * 100)),
            ],
        ]);

        return $this->fetch('module:' . $this->name . '/views/templates/hook/cart-free-shipping.tpl');
    }

    private function getCartZoneId(Cart $cart): int
    {
        if ($cart->id_address_delivery) {
            return (int) Address::getZoneById((int) $cart->id_address_delivery);
        }

        return (int) Country::getIdZone((int) Configuration::get('PS_COUNTRY_DEFAULT'));
    }

    /*
     * 3. displayOrderDetailProductLine (Hummingbird >= 2.1.1)
     */
    public function hookDisplayOrderDetailProductLine(array $params): string
    {
        $months = (int) Configuration::get(self::CONFIG_WARRANTY_MONTHS);
        $order = $this->getOrder((int) ($params['id_order'] ?? 0));
        if ($months <= 0 || $order === null) {
            return '';
        }

        // The warranty starts on delivery; before that, fall back on the order date.
        $start = Validate::isDate($order->delivery_date) && $order->delivery_date !== '0000-00-00 00:00:00'
            ? $order->delivery_date
            : $order->date_add;
        $end = (new DateTimeImmutable($start))->modify(sprintf('+%d months', $months));

        $this->context->smarty->assign([
            'warranty' => [
                'end_date' => Tools::displayDate($end->format('Y-m-d')),
                'active' => $end > new DateTimeImmutable(),
            ],
        ]);

        return $this->fetch('module:' . $this->name . '/views/templates/hook/order-line-warranty.tpl');
    }

    /**
     * The hook runs once per product line: load each order only once.
     */
    private function getOrder(int $idOrder): ?Order
    {
        if (!array_key_exists($idOrder, $this->orderCache)) {
            $order = new Order($idOrder);
            $isOwner = Validate::isLoadedObject($order)
                && (int) $order->id_customer === (int) $this->context->customer->id;
            $this->orderCache[$idOrder] = $isOwner ? $order : null;
        }

        return $this->orderCache[$idOrder];
    }

    /*
     * 4. displaySubcategories
     */
    public function hookDisplaySubcategories(array $params): string
    {
        $controller = $this->context->controller;
        if (!$controller instanceof CategoryController) {
            return '';
        }

        $brands = $this->getCategoryBrands((int) $controller->getCategory()->id);
        if (empty($brands)) {
            return '';
        }

        $withImages = !empty($params['displaySubcategoryImages']);
        foreach ($brands as &$brand) {
            $brand['url'] = $this->context->link->getManufacturerLink((int) $brand['id_manufacturer']);
            $brand['image'] = $withImages
                ? $this->context->link->getManufacturerImageLink((int) $brand['id_manufacturer'], 'small_default')
                : null;
        }
        unset($brand);

        $this->context->smarty->assign([
            'brands' => $brands,
            'with_images' => $withImages,
        ]);

        return $this->fetch('module:' . $this->name . '/views/templates/hook/subcategories-brands.tpl');
    }

    /**
     * @return array<int, array{id_manufacturer: string, name: string}>
     */
    private function getCategoryBrands(int $idCategory): array
    {
        $idShop = (int) $this->context->shop->id;

        return Db::getInstance()->executeS(
            'SELECT DISTINCT m.`id_manufacturer`, m.`name`
            FROM `' . _DB_PREFIX_ . 'category_product` cp
            INNER JOIN `' . _DB_PREFIX_ . 'product` p ON p.`id_product` = cp.`id_product`
            INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps ON ps.`id_product` = p.`id_product`
                AND ps.`id_shop` = ' . $idShop . ' AND ps.`active` = 1
                AND ps.`visibility` IN ("both", "catalog")
            INNER JOIN `' . _DB_PREFIX_ . 'manufacturer` m ON m.`id_manufacturer` = p.`id_manufacturer`
                AND m.`active` = 1
            INNER JOIN `' . _DB_PREFIX_ . 'manufacturer_shop` ms ON ms.`id_manufacturer` = m.`id_manufacturer`
                AND ms.`id_shop` = ' . $idShop . '
            WHERE cp.`id_category` = ' . $idCategory . '
            ORDER BY m.`name`
            LIMIT 6'
        ) ?: [];
    }

    /*
     * 5. actionNotFound
     */
    public function hookActionNotFound(array $params): void
    {
        $path = mb_substr((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), 0, 255);
        if ($path === '') {
            return;
        }

        $db = Db::getInstance();
        $table = _DB_PREFIX_ . self::NOT_FOUND_TABLE;
        $idShop = (int) $this->context->shop->id;

        $db->execute(
            'INSERT INTO `' . $table . '` (`id_shop`, `request_uri`, `hits`, `date_last_hit`)
            VALUES (' . $idShop . ', "' . pSQL($path) . '", 1, NOW())
            ON DUPLICATE KEY UPDATE `hits` = `hits` + 1, `date_last_hit` = NOW()'
        );

        $target = (string) $db->getValue(
            'SELECT `redirect_to` FROM `' . $table . '`
            WHERE `id_shop` = ' . $idShop . ' AND `request_uri` = "' . pSQL($path) . '"'
        );
        if ($target === '') {
            return;
        }

        // Tools::redirect() reads a relative value as a page name: always give it an absolute URL.
        if (!preg_match('@^https?://@i', $target)) {
            $target = Tools::getShopDomainSsl(true) . '/' . ltrim($target, '/');
        }

        Tools::redirect($target, __PS_BASE_URI__, null, 'HTTP/1.1 301 Moved Permanently');
    }

    /*
     * 6. Back office: actionOrderReturnForm
     */
    public function hookActionOrderReturnForm(array $params): void
    {
        /** @var FormBuilderInterface $builder */
        $builder = $params['form_builder'];

        $builder->add('pe_return_email', EmailType::class, [
            'label' => $this->trans('Returns department email', [], 'Modules.Pehooks92.Admin'),
            'required' => false,
            // Not mapped: the core configuration rejects any key it does not know,
            // with a 500 error, before actionOrderReturnSave is even called.
            'mapped' => false,
            'data' => (string) Configuration::get(self::CONFIG_RETURN_EMAIL),
            'constraints' => [new Assert\Email()],
        ]);

        // Priority -10: runs after the validation listener, so isValid() is reliable.
        $builder->addEventListener(FormEvents::POST_SUBMIT, static function (FormEvent $event): void {
            $form = $event->getForm();
            if ($form->isValid()) {
                Configuration::updateValue(
                    self::CONFIG_RETURN_EMAIL,
                    trim((string) $form->get('pe_return_email')->getData())
                );
            }
        }, -10);
    }
}
