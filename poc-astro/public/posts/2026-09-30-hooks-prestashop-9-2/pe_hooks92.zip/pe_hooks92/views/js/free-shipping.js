/**
 * The cart page refreshes its totals in AJAX, but not the hook blocks around them:
 * reload our block each time the cart changes.
 */
document.addEventListener('DOMContentLoaded', () => {
  const container = document.querySelector('.js-pe-free-shipping');

  if (!container || typeof prestashop === 'undefined') {
    return;
  }

  prestashop.on('updatedCart', async () => {
    const response = await fetch(container.dataset.refreshUrl, {
      headers: {'X-Requested-With': 'XMLHttpRequest'},
    });

    if (response.ok) {
      container.innerHTML = await response.text();
    }
  });
});
