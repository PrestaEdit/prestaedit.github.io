{* Same markup as the theme subcategories, so brands blend into the list *}
{foreach from=$brands item=brand}
  <a class="subcategory__link{if $with_images} subcategory__link--with-image{/if}" href="{$brand.url}" title="{$brand.name}">
    {if $with_images}
      <img class="subcategory__thumbnail img-fluid" src="{$brand.image}" alt="{$brand.name}" loading="lazy">
    {/if}
    <span class="subcategory__name">{$brand.name}</span>
  </a>
{/foreach}
