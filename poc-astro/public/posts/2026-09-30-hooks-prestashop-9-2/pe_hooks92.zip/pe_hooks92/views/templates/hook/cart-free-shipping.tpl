<div class="pe-free-shipping mt-3" role="status">
  {if $free_shipping.reached}
    <p class="mb-2 fw-bold text-success">
      {l s='Free shipping unlocked!' d='Modules.Pehooks92.Shop'}
    </p>
  {else}
    <p class="mb-2">
      {l s='Only %amount% left to get free shipping.' sprintf=['%amount%' => $free_shipping.remaining] d='Modules.Pehooks92.Shop'}
    </p>
  {/if}
  <div class="progress" role="progressbar" aria-valuenow="{$free_shipping.percent}" aria-valuemin="0" aria-valuemax="100">
    <div class="progress-bar{if $free_shipping.reached} bg-success{/if}" style="width: {$free_shipping.percent}%"></div>
  </div>
</div>
