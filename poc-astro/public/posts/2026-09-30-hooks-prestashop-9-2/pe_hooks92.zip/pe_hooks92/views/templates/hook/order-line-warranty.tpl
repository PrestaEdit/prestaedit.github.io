<span class="pe-warranty d-block mt-1 small">
  {if $warranty.active}
    <span class="badge bg-success">{l s='Under warranty' d='Modules.Pehooks92.Shop'}</span>
    {l s='until %date%' sprintf=['%date%' => $warranty.end_date] d='Modules.Pehooks92.Shop'}
  {else}
    <span class="badge bg-secondary">{l s='Warranty expired' d='Modules.Pehooks92.Shop'}</span>
    {l s='since %date%' sprintf=['%date%' => $warranty.end_date] d='Modules.Pehooks92.Shop'}
  {/if}
</span>
