{extends file='checkout/_partials/steps/checkout-step.tpl'}

{block name='step_content'}
  <form method="post" class="purchase-order__form" novalidate>
    <div class="mb-3">
      <label class="form-label required" for="purchase_order">
        {l s='Your purchase order number' d='Modules.Pehooks92.Shop'}
      </label>
      <input
        type="text"
        class="form-control{if $purchase_order_error} is-invalid{/if}"
        id="purchase_order"
        name="purchase_order"
        value="{$purchase_order}"
        maxlength="40"
        autocomplete="off"
        required
      >
      {if $purchase_order_error}
        <div class="invalid-feedback">{$purchase_order_error}</div>
      {else}
        <div class="form-text">{l s='It will be attached to your order.' d='Modules.Pehooks92.Shop'}</div>
      {/if}
    </div>

    <div class="buttons-wrapper buttons-wrapper--split buttons-wrapper--invert-mobile mt-3">
      {include file='checkout/_partials/checkout-step-buttons.tpl' submit_name='submitPurchaseOrder' submit_value='1'}
    </div>
  </form>
{/block}
