# pe_hooks92

Demo module for the new front office hooks of PrestaShop 9.2, written for the blog article
"Les hooks de PrestaShop 9.2, testés en conditions réelles".

| Hook | What the demo does |
| --- | --- |
| `actionCheckoutBuildProcess` | B2B checkout (addresses, shipping, purchase order number, payment) for one customer group |
| `displayCartBelowSummary` | Free shipping progress bar, refreshed on every cart update |
| `displayOrderDetailProductLine` | Warranty end date on each product line of the order detail |
| `displaySubcategories` | Brands of the category, displayed like subcategories |
| `actionNotFound` | 404 log with hit counter and optional 301 redirection |
| `actionOrderReturnForm` | Extra "Returns department email" field in the merchandise returns options |

## Requirements

- PrestaShop 9.2.0 or later (tested on 9.2.0-rc.1)
- Hummingbird theme. `displayOrderDetailProductLine` needs Hummingbird 2.1.1 or later.
  The Classic theme does not call the three display hooks.

## Installation

```bash
composer dump-autoload --no-dev
php bin/console prestashop:module install pe_hooks92
```

## Configuration

There is no configuration page, set the values with the console:

```bash
# Customer group that gets the B2B checkout (0 = disabled, default)
php bin/console prestashop:config set PE_HOOKS92_B2B_GROUP --value 3
# Warranty length in months (default 24)
php bin/console prestashop:config set PE_HOOKS92_WARRANTY_MONTHS --value 24
```

301 redirections are rows of `PREFIX_pe_hooks92_not_found`: fill `redirect_to` for a logged URL.

The B2B checkout only applies when it is the only enabled checkout provider.
If the one-page checkout module (`ps_onepagecheckout`) is also enabled, PrestaShop falls back to the native checkout.
