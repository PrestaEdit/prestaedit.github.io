<?php
declare(strict_types=1);

namespace PrestaEdit\Hooks92\Checkout;

use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Custom checkout step asking for the customer purchase order number.
 */
class CheckoutPurchaseOrderStep extends \AbstractCheckoutStep
{
    public const IDENTIFIER = 'checkout-purchase-order-step';

    private string $purchaseOrder = '';
    private string $error = '';

    public function __construct(\Context $context, TranslatorInterface $translator)
    {
        parent::__construct($context, $translator);
        $this->setTemplate('module:pe_hooks92/views/templates/front/checkout/purchase-order-step.tpl');
    }

    /**
     * The default identifier is built from the class name, namespace included:
     * it ends up as an HTML id and a JSON key, so keep it simple.
     */
    public function getIdentifier(): string
    {
        return self::IDENTIFIER;
    }

    public function handleRequest(array $requestParameters = [])
    {
        $this->setTitle($this->getTranslator()->trans('Purchase order', [], 'Modules.Pehooks92.Shop'));

        if (!$this->isReachable() || !isset($requestParameters['submitPurchaseOrder'])) {
            return;
        }

        $purchaseOrder = trim((string) ($requestParameters['purchase_order'] ?? ''));
        $this->purchaseOrder = $purchaseOrder;

        if (!preg_match('/^[\p{L}\p{N} \/._-]{3,40}$/u', $purchaseOrder)) {
            $this->error = $this->getTranslator()->trans(
                'Please enter a valid purchase order number (3 to 40 characters).',
                [],
                'Modules.Pehooks92.Shop'
            );
            $this->setComplete(false);
            $this->setCurrent(true);
            $this->getCheckoutProcess()->setHasErrors(true);

            return;
        }

        $this->setComplete(true);
        $this->setNextStepAsCurrent();
    }

    public function render(array $extraParams = [])
    {
        return $this->renderTemplate($this->getTemplate(), $extraParams, [
            'purchase_order' => $this->purchaseOrder,
            'purchase_order_error' => $this->error,
        ]);
    }

    public function getDataToPersist()
    {
        return ['purchase_order' => $this->purchaseOrder];
    }

    public function restorePersistedData(array $data)
    {
        $this->purchaseOrder = (string) ($data['purchase_order'] ?? '');

        return $this;
    }

    /**
     * Reads the value persisted by OrderController in cart.checkout_session_data.
     */
    public static function getPurchaseOrderFromCart(int $idCart): string
    {
        $data = json_decode((string) \Db::getInstance()->getValue(
            'SELECT `checkout_session_data` FROM `' . _DB_PREFIX_ . 'cart` WHERE `id_cart` = ' . $idCart
        ), true);

        $step = $data[self::IDENTIFIER] ?? [];

        return empty($step['step_is_complete']) ? '' : (string) ($step['purchase_order'] ?? '');
    }
}
