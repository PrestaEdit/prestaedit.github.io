<?php
declare(strict_types=1);

namespace PrestaEdit\Hooks92\Checkout;

use PrestaShop\PrestaShop\Adapter\Order\Checkout\CheckoutProcessProviderInterface;
use PrestaShopBundle\Translation\TranslatorComponent;

/**
 * Checkout for professional customers: addresses, shipping, purchase order number, payment.
 * The "personal information" step is dropped, the customer is always logged in here.
 */
final class B2bCheckoutProvider implements CheckoutProcessProviderInterface
{
    public function __construct(
        private readonly \Context $context,
    ) {
    }

    /**
     * Returning false keeps the native checkout for everybody else.
     */
    public function isEnabled(): bool
    {
        $idGroup = (int) \Configuration::get(\Pe_Hooks92::CONFIG_B2B_GROUP);
        $customer = $this->context->customer;

        return $idGroup > 0
            && $customer->isLogged()
            && in_array($idGroup, array_map('intval', $customer->getGroups()), true);
    }

    public function buildCheckoutProcess(
        \CheckoutSession $session,
        TranslatorComponent $translator,
    ): \CheckoutProcess {
        $process = new \CheckoutProcess($this->context, $session);

        $process->addStep(new \CheckoutAddressesStep(
            $this->context,
            $translator,
            $this->makeAddressForm($translator)
        ));

        if (!$this->context->cart->isVirtualCart()) {
            $process->addStep($this->makeDeliveryStep($translator));
        }

        $process
            ->addStep(new CheckoutPurchaseOrderStep($this->context, $translator))
            ->addStep(new \CheckoutPaymentStep(
                $this->context,
                $translator,
                new \PaymentOptionsFinder(),
                new \ConditionsToApproveFinder($this->context, $translator)
            ));

        return $process;
    }

    /**
     * Same form as FrontController::makeAddressForm(), which is protected.
     */
    private function makeAddressForm(TranslatorComponent $translator): \CustomerAddressForm
    {
        $idLang = (int) $this->context->language->id;
        $countries = \Configuration::get('PS_RESTRICT_DELIVERED_COUNTRIES')
            ? \Carrier::getDeliveredCountries($idLang, true, true)
            : \Country::getCountries($idLang, true);

        $form = new \CustomerAddressForm(
            $this->context->smarty,
            $this->context->language,
            $translator,
            new \CustomerAddressPersister(
                $this->context->customer,
                $this->context->cart,
                \Tools::getToken(true, $this->context)
            ),
            new \CustomerAddressFormatter($this->context->country, $translator, $countries)
        );
        $form->setAction($this->context->link->getPageLink('order'));

        return $form;
    }

    /**
     * Same settings as OrderController::buildCheckoutProcess().
     */
    private function makeDeliveryStep(TranslatorComponent $translator): \CheckoutDeliveryStep
    {
        $cart = $this->context->cart;
        $step = new \CheckoutDeliveryStep($this->context, $translator);

        $step
            ->setRecyclablePackAllowed((bool) \Configuration::get('PS_RECYCLABLE_PACK'))
            ->setGiftAllowed((bool) \Configuration::get('PS_GIFT_WRAPPING'))
            ->setIncludeTaxes(
                !\Product::getTaxCalculationMethod((int) $cart->id_customer)
                && (int) \Configuration::get('PS_TAX')
            )
            ->setDisplayTaxesLabel(\Configuration::get('PS_TAX'))
            ->setGiftCost($cart->getGiftWrappingPrice($step->getIncludeTaxes()));

        return $step;
    }
}
